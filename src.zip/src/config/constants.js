export const NOT_FOUND = "NOT_FOUND"
export const RESTRICTED = "RESTRICTED"
export const ACTIVATED = "ACTIVATED"