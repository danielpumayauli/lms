import React, { useState, useEffect } from 'react'


import withLayout from '../../HOC/withLayout'
import CourseNavigation from '../../Organisms/CourseNavigation'
import withValidationCourse from '../../HOC/withValidationCourse'

import ModuleCard from '../../Organisms/ModuleCard'
import Loader from '../../Organisms/Loader'

const Course = ({match, name, options, is_student}) => {

  const [data, setData] = useState(null);
  useEffect(() => {

  
    setData('ok'); 

  }, [match]);

  const drawModules = () => {
    return <div id="course-content" className="col-md-10 p-x-3 p-y-1">
              

            <div className="row" style={{backgroundColor: ''}}>
              <div className="col-md-3" >
                    <ModuleCard id={1} name='Semana 1' code='semana_1' img={2} />
              </div>
              <div className="col-md-3" >
                    <ModuleCard id={1} name='Semana 2' code='semana_2' img={3} />
              </div>
              <div className="col-md-3" >
                    <ModuleCard id={1} name='Semana 3' code='semana_3' img={4} />
              </div>
              <div className="col-md-3" >
                    <ModuleCard id={1} name='Semana 4' code='semana_4' img={3}/>
              </div>
              <div className="col-md-3" >
                    <ModuleCard id={1} name='Semana 5' code='semana_5' img={1}/>
              </div>
            </div>
            
        </div>
  }

  
    return (

      <>

      <div className="header pb-6 mr-top-fx">
        <div className="container-fluid">
            <div className="header-body">
              <div className="row align-items-center py-4">
                  <div className="col-lg-6 col-7">
                    <p className="d-inline-block mb-0 breat-fx"><i className="fa fa-folder-open text-info"></i> {name}</p>
                  </div>
              </div>
            </div>
        </div>
      </div>

      <div className="container-fluid mt--6">
        <div className="row">
          <CourseNavigation id={match.params.id} options={options} is_student={is_student}/>
            
          
          {/* <div className="col-md-10 p-x-3 p-y-1" style={{backgroundColor: 'white', 
                                                          display: 'flex',
                                                          justifyContent: 'center',
                                                          alignItems: 'center'}}>
            <p>Este curso aún no cuenta con contenido para mostrar</p>
          </div> */}
          {data ? drawModules() : <Loader />}

        </div> 
      </div>

        


    </>
    )
  
}


export default  withLayout()(withValidationCourse()(Course)) 
