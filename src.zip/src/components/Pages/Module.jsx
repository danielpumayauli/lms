import React from 'react'
import withLayout from '../HOC/withLayout'



const Module = () => {
  return (
    <>
              <div className="header pb-6 mr-top-fx">
                <div className="container-fluid">
                    <div className="header-body">
                      <div className="row align-items-center py-4">
                          <div className="col-lg-6 col-7">
                            <p className="d-inline-block mb-0 breat-fx"><i className="fa fa-folder-open text-info"></i> Universidad San Ignacio de Loyola > Visor de documentos del modulo</p>
                          </div>
                      </div>
                    </div>
                </div>
              </div>
      
              <div className="container-fluid mt--7">
                <div className="row">
                  <div className="col-md-8">
                    <div className="card">
                        <div className="codigo-curso">VISOR</div>                      
                        
                     </div>

                     <div id="presentation">


                     <object style={{width: 100+'%', minHeight: 500+'px'}}  
                          data="https://contenidoscev.usil.edu.pe/EPG/MBA-DG/metodos_cuantitativos/Unidad_1/Video_introductorio/MCN_UD1_Intro/story_html5.html">

                      </object>




                     </div>
                  </div>
                  <div className="col-md-4">
                    <div className="card">
                        <div className="codigo-curso">ITINERARIO</div>
                        
                        
                    </div>
                    <div className="accordion" id="accordionExample">
                      <div className="card">
                        <div className="card-header" id="headingOne">
                          <h2 className="mb-0">
                            <button className="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                              Inicio
                            </button>
                          </h2>
                        </div>

                        <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                          <div className="card-body">
                          <ul className="list-group list-group-flush">
                            <li className="list-group-item active">MCN_UD1_Intro</li>
                            <li className="list-group-item">MCN_UD2</li>
                            <li className="list-group-item">MCN_UD3</li>
                            <li className="list-group-item">MCN_UD4</li>
                            <li className="list-group-item">MCN_UD5</li>
                          </ul>
                          </div>
                        </div>
                      </div>
                      <div className="card">
                        <div className="card-header" id="headingTwo">
                          <h2 className="mb-0">
                            <button className="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                              Desarrollo
                            </button>
                          </h2>
                        </div>
                        <div id="collapseTwo" className="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                          <div className="card-body">
                            Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                          </div>
                        </div>
                      </div>
                      <div className="card">
                        <div className="card-header" id="headingThree">
                          <h2 className="mb-0">
                            <button className="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                              Cierre
                            </button>
                          </h2>
                        </div>
                        <div id="collapseThree" className="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                          <div className="card-body">
                            Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
      
              </div>
      
      
      </>
  )
}


export default  withLayout()(Module) 
